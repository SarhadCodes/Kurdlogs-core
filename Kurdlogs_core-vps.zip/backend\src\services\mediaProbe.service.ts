import fs from 'fs';
import { spawn } from 'child_process';
import { env } from '../config/env';

interface CacheEntry {
  mtimeMs: number;
  durationSec: number;
}

const durationCache = new Map<string, CacheEntry>();

function ffprobePath(): string {
  return env.FFMPEG_PATH.replace(/ffmpeg(\.exe)?$/i, 'ffprobe$1');
}

function probeDurationUncached(filePath: string): Promise<number | undefined> {
  return new Promise((resolve) => {
    const probe = spawn(ffprobePath(), [
      '-v',
      'error',
      '-show_entries',
      'format=duration',
      '-of',
      'default=noprint_wrappers=1:nokey=1',
      filePath,
    ]);
    let output = '';
    probe.stdout.on('data', (d) => {
      output += d.toString();
    });
    probe.on('close', (code) => {
      if (code === 0) {
        const dur = parseFloat(output.trim());
        resolve(Number.isFinite(dur) && dur > 0 ? dur : undefined);
      } else {
        resolve(undefined);
      }
    });
    probe.on('error', () => resolve(undefined));
  });
}

/** Cached ffprobe duration — used so cursor timing matches actual FFmpeg playback. */
export async function probeMediaDurationSec(filePath: string): Promise<number | undefined> {
  if (!filePath || !fs.existsSync(filePath)) return undefined;
  try {
    const mtimeMs = fs.statSync(filePath).mtimeMs;
    const cached = durationCache.get(filePath);
    if (cached && cached.mtimeMs === mtimeMs) return cached.durationSec;

    const durationSec = await probeDurationUncached(filePath);
    if (durationSec != null) {
      durationCache.set(filePath, { mtimeMs, durationSec });
    }
    return durationSec;
  } catch {
    return undefined;
  }
}

export function clearMediaDurationCache(filePath?: string): void {
  if (filePath) durationCache.delete(filePath);
  else durationCache.clear();
}
