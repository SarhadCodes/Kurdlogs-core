  /** Bump when deploying — visible in sidebar so you can confirm VPS has the new build. */
export const BUILD_VERSION = '2026-06-22-v18.5.5-blueprint-http-uuid-fix';
